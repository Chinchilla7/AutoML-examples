# Summary of 2_DecisionTree

[<< Go back](../README.md)


## Decision Tree
- **n_jobs**: -1
- **criterion**: gini
- **max_depth**: 3
- **num_class**: 6
- **explain_level**: 2

## Validation
 - **validation_type**: split
 - **train_ratio**: 0.75
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

27.0 seconds

### Metric details
|           |   Elective |   Emergency |    Newborn |   Not Available |   Trauma |      Urgent |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|------------:|-----------:|----------------:|---------:|------------:|-----------:|------------:|---------------:|----------:|
| precision |   0.582861 |    0.975762 |   0.993023 |               0 |        0 |   0.625     |   0.850136 |    0.529441 |       0.872711 |  0.376179 |
| recall    |   0.973964 |    0.889206 |   0.997664 |               0 |        0 |   0.0458716 |   0.850136 |    0.484451 |       0.850136 |  0.376179 |
| f1-score  |   0.729287 |    0.930475 |   0.995338 |               0 |        0 |   0.0854701 |   0.850136 |    0.456762 |       0.832289 |  0.376179 |
| support   | 845        | 2807        | 428        |               5 |       12 | 327         |   0.850136 | 4424        |    4424        |  0.376179 |


## Confusion matrix
|                          |   Predicted as Elective |   Predicted as Emergency |   Predicted as Newborn |   Predicted as Not Available |   Predicted as Trauma |   Predicted as Urgent |
|:-------------------------|------------------------:|-------------------------:|-----------------------:|-----------------------------:|----------------------:|----------------------:|
| Labeled as Elective      |                     823 |                       16 |                      0 |                            0 |                     0 |                     6 |
| Labeled as Emergency     |                     308 |                     2496 |                      1 |                            0 |                     0 |                     2 |
| Labeled as Newborn       |                       0 |                        0 |                    427 |                            0 |                     0 |                     1 |
| Labeled as Not Available |                       0 |                        5 |                      0 |                            0 |                     0 |                     0 |
| Labeled as Trauma        |                       1 |                       11 |                      0 |                            0 |                     0 |                     0 |
| Labeled as Urgent        |                     280 |                       30 |                      2 |                            0 |                     0 |                    15 |

## Learning curves
![Learning curves](learning_curves.png)

## Decision Tree 

### Tree #1
![Tree 1](learner_fold_0_tree.svg)

### Rules

if (Emergency Department Indicator > 0.5) and (APR MDC Description <= 23.0) and (Hospital County <= 55.5) then class: Emergency (proba: 98.37%) | based on 7,289 samples

if (Emergency Department Indicator <= 0.5) and (Birth Weight <= 50.0) and (APR Medical Surgical Description <= 1.0) then class: Elective (proba: 41.56%) | based on 2,156 samples

if (Emergency Department Indicator <= 0.5) and (Birth Weight <= 50.0) and (APR Medical Surgical Description > 1.0) then class: Elective (proba: 77.16%) | based on 2,053 samples

if (Emergency Department Indicator <= 0.5) and (Birth Weight > 50.0) and (CCS Diagnosis Code <= 218.5) then class: Newborn (proba: 99.3%) | based on 1,290 samples

if (Emergency Department Indicator > 0.5) and (APR MDC Description > 23.0) and (Facility Id <= 1739.0) then class: Emergency (proba: 84.27%) | based on 426 samples

if (Emergency Department Indicator > 0.5) and (APR MDC Description > 23.0) and (Facility Id > 1739.0) then class: Urgent (proba: 88.57%) | based on 35 samples

if (Emergency Department Indicator <= 0.5) and (Birth Weight > 50.0) and (CCS Diagnosis Code > 218.5) then class: Urgent (proba: 52.94%) | based on 17 samples

if (Emergency Department Indicator > 0.5) and (APR MDC Description <= 23.0) and (Hospital County > 55.5) then class: Urgent (proba: 80.0%) | based on 5 samples





## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



## SHAP Importance
![SHAP Importance](shap_importance.png)

## SHAP Dependence plots

### Dependence Elective (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Elective.png)
### Dependence Emergency (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Emergency.png)
### Dependence Newborn (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Newborn.png)
### Dependence Not Available (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Not Available.png)
### Dependence Trauma (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Trauma.png)
### Dependence Urgent (Fold 1)
![SHAP Dependence from fold 1](learner_fold_0_shap_dependence_class_Urgent.png)

## SHAP Decision plots

### Worst decisions for selected sample 1 (Fold 1)
![SHAP worst decisions from Fold 1](learner_fold_0_sample_0_worst_decisions.png)
### Worst decisions for selected sample 2 (Fold 1)
![SHAP worst decisions from Fold 1](learner_fold_0_sample_1_worst_decisions.png)
### Worst decisions for selected sample 3 (Fold 1)
![SHAP worst decisions from Fold 1](learner_fold_0_sample_2_worst_decisions.png)
### Worst decisions for selected sample 4 (Fold 1)
![SHAP worst decisions from Fold 1](learner_fold_0_sample_3_worst_decisions.png)
### Best decisions for selected sample 1 (Fold 1)
![SHAP best decisions from Fold 1](learner_fold_0_sample_0_best_decisions.png)
### Best decisions for selected sample 2 (Fold 1)
![SHAP best decisions from Fold 1](learner_fold_0_sample_1_best_decisions.png)
### Best decisions for selected sample 3 (Fold 1)
![SHAP best decisions from Fold 1](learner_fold_0_sample_2_best_decisions.png)
### Best decisions for selected sample 4 (Fold 1)
![SHAP best decisions from Fold 1](learner_fold_0_sample_3_best_decisions.png)

[<< Go back](../README.md)
