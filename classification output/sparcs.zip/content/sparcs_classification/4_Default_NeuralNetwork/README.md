# Summary of 4_Default_NeuralNetwork

[<< Go back](../README.md)


## Neural Network
- **n_jobs**: -1
- **dense_1_size**: 32
- **dense_2_size**: 16
- **learning_rate**: 0.05
- **num_class**: 6
- **explain_level**: 2

## Validation
 - **validation_type**: split
 - **train_ratio**: 0.75
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

8.8 seconds

### Metric details
|           |   Elective |   Emergency |    Newborn |   Not Available |   Trauma |     Urgent |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|------------:|-----------:|----------------:|---------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.770492 |    0.935484 |   0.979167 |               0 |        0 |   0.475556 |   0.882233 |    0.526783 |       0.870606 |  0.359239 |
| recall    |   0.83432  |    0.950481 |   0.988318 |               0 |        0 |   0.327217 |   0.882233 |    0.516723 |       0.882233 |  0.359239 |
| f1-score  |   0.801136 |    0.942923 |   0.983721 |               0 |        0 |   0.387681 |   0.882233 |    0.519244 |       0.875124 |  0.359239 |
| support   | 845        | 2807        | 428        |               5 |       12 | 327        |   0.882233 | 4424        |    4424        |  0.359239 |


## Confusion matrix
|                          |   Predicted as Elective |   Predicted as Emergency |   Predicted as Newborn |   Predicted as Not Available |   Predicted as Trauma |   Predicted as Urgent |
|:-------------------------|------------------------:|-------------------------:|-----------------------:|-----------------------------:|----------------------:|----------------------:|
| Labeled as Elective      |                     705 |                       68 |                      4 |                            0 |                     0 |                    68 |
| Labeled as Emergency     |                      91 |                     2668 |                      1 |                            0 |                     0 |                    47 |
| Labeled as Newborn       |                       2 |                        0 |                    423 |                            0 |                     0 |                     3 |
| Labeled as Not Available |                       0 |                        5 |                      0 |                            0 |                     0 |                     0 |
| Labeled as Trauma        |                       1 |                       11 |                      0 |                            0 |                     0 |                     0 |
| Labeled as Urgent        |                     116 |                      100 |                      4 |                            0 |                     0 |                   107 |

## Learning curves
![Learning curves](learning_curves.png)

## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



[<< Go back](../README.md)
