# Summary of Ensemble

[<< Go back](../README.md)


## Ensemble structure
| Model             |   Weight |
|:------------------|---------:|
| 3_Default_Xgboost |        1 |

### Metric details
|           |   Elective |   Emergency |    Newborn |   Not Available |   Trauma |     Urgent |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|------------:|-----------:|----------------:|---------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.823982 |    0.959646 |   0.995338 |             0.8 |     1    |   0.743083 |   0.922694 |    0.887008 |       0.921109 |  0.221934 |
| recall    |   0.886391 |    0.9658   |   0.997664 |             0.8 |     0.25 |   0.574924 |   0.922694 |    0.745796 |       0.922694 |  0.221934 |
| f1-score  |   0.854048 |    0.962713 |   0.996499 |             0.8 |     0.4  |   0.648276 |   0.922694 |    0.776923 |       0.920274 |  0.221934 |
| support   | 845        | 2807        | 428        |             5   |    12    | 327        |   0.922694 | 4424        |    4424        |  0.221934 |


## Confusion matrix
|                          |   Predicted as Elective |   Predicted as Emergency |   Predicted as Newborn |   Predicted as Not Available |   Predicted as Trauma |   Predicted as Urgent |
|:-------------------------|------------------------:|-------------------------:|-----------------------:|-----------------------------:|----------------------:|----------------------:|
| Labeled as Elective      |                     749 |                       54 |                      0 |                            1 |                     0 |                    41 |
| Labeled as Emergency     |                      71 |                     2711 |                      1 |                            0 |                     0 |                    24 |
| Labeled as Newborn       |                       0 |                        1 |                    427 |                            0 |                     0 |                     0 |
| Labeled as Not Available |                       0 |                        1 |                      0 |                            4 |                     0 |                     0 |
| Labeled as Trauma        |                       0 |                        9 |                      0 |                            0 |                     3 |                     0 |
| Labeled as Urgent        |                      89 |                       49 |                      1 |                            0 |                     0 |                   188 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



[<< Go back](../README.md)
