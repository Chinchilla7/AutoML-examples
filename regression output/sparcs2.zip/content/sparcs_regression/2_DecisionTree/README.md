# Summary of 2_DecisionTree

[<< Go back](../README.md)


## Decision Tree
- **n_jobs**: -1
- **criterion**: mse
- **max_depth**: 3
- **explain_level**: 2

## Validation
 - **validation_type**: split
 - **train_ratio**: 0.75
 - **shuffle**: True

## Optimized metric
rmse

## Training time

4.2 seconds

### Metric details:
| Metric   |      Score |
|:---------|-----------:|
| MAE      |  11.4368   |
| MSE      | 238.051    |
| RMSE     |  15.4289   |
| R2       |   0.735208 |
| MAPE     |   0.415248 |



## Learning curves
![Learning curves](learning_curves.png)

## Decision Tree 

### Tree #1
![Tree 1](learner_fold_0_tree.svg)

### Rules

if (NOX > 0.517) and (DIS <= 2.375) and (NOX > 0.59) then response: 95.017 | based on 107 samples

if (NOX <= 0.517) and (DIS > 4.065) and (LSTAT <= 9.12) then response: 31.655 | based on 78 samples

if (NOX > 0.517) and (DIS > 2.375) and (MEDV > 19.85) then response: 67.041 | based on 44 samples

if (NOX > 0.517) and (DIS > 2.375) and (MEDV <= 19.85) then response: 87.067 | based on 43 samples

if (NOX <= 0.517) and (DIS > 4.065) and (LSTAT > 9.12) then response: 52.454 | based on 41 samples

if (NOX <= 0.517) and (DIS <= 4.065) and (DIS > 3.04) then response: 61.765 | based on 40 samples

if (NOX > 0.517) and (DIS <= 2.375) and (NOX <= 0.59) then response: 85.544 | based on 16 samples

if (NOX <= 0.517) and (DIS <= 4.065) and (DIS <= 3.04) then response: 82.35 | based on 10 samples





## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## True vs Predicted

![True vs Predicted](true_vs_predicted.png)


## Predicted vs Residuals

![Predicted vs Residuals](predicted_vs_residuals.png)



## SHAP Importance
![SHAP Importance](shap_importance.png)

## SHAP Dependence plots

### Dependence (Fold 1)
![SHAP Dependence from Fold 1](learner_fold_0_shap_dependence.png)

## SHAP Decision plots

### Top-10 Worst decisions (Fold 1)
![SHAP worst decisions from fold 1](learner_fold_0_shap_worst_decisions.png)
### Top-10 Best decisions (Fold 1)
![SHAP best decisions from fold 1](learner_fold_0_shap_best_decisions.png)

[<< Go back](../README.md)
